
public class testRectangle {

	public static void main(String[] args) {
		Rectangle r1 = new Rectangle(4, 40);

		System.out.println("Rectangle 1 width: " + r1.width);
		System.out.println("Rectangle 1 Height: " + r1.height);
		System.out.println("Rectangle 1 area: " + r1.getArea());
		System.out.println("Rectangle 1 perimeter: " + r1.getPerimeter());

		System.out.println("------------------------------");
		Rectangle r2 = new Rectangle(3.5, 35.9);

		System.out.println("Rectangle 2 width: " + r2.width);
		System.out.println("Rectangle 2 Height: " + r2.height);
		System.out.println("Rectangle 2 area: " + r2.getArea());
		System.out.println("Rectangle 2 perimeter: " + r2.getPerimeter());

	}

}
